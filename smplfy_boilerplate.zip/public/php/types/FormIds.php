<?php
/**
 * A types file can be used to organise unique identifiers that are commonly used throughout your plugin
 */

namespace SMPLFY\boilerplate;
class FormIds {
	const EXAMPLE_FORM_ID = 9999;
    const CONTACT_US = 1;
}